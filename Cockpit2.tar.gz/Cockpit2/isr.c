// Interrupt service routines
#include <htc.h>
#include "adc.h"

void interrupt my_isr(void){

	/***** A2D Converter Code *****/
	if((ADIE)&&(ADIF)){
		adc_interrupt();
		ADIF=0;	// clear event flag
	}

	/***** Timer 1 Code *****/
	if((TMR1IE)&&(TMR1IF)){
		PORTD = ~PORTD;
		TMR1IF=0;	// clear event flag
	}
	
}
