// Peripheral initialization function
extern void init(void);
