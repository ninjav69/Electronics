#ifndef UART_H_
#define UART_H_

void putc(unsigned char byte);

unsigned char getc(void);

#endif /*UART_H_*/
