/*
 * Site-wide configuration for this program.
 */
#ifndef CONFIG_H_
#define CONFIG_H_

#ifndef _XTAL_FREQ
#define _XTAL_FREQ 20000000
#endif // _XTAL_FREQ


#endif /*CONFIG_H_*/
